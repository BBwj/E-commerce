package lyons.dao;

/**
 * 
 * Classify.xml ��Ӧ�Ľӿ�
 * 
 * @author lyons(zhanglei)
 * 
 */
public interface GoodsClassifyDao
{
    
}
